
/**
 * @file
 * Defines Javascript behaviors for the Knowledge module.
 **/

(function ($) {

    $(document).ready(function(){        
        $("#edit-field-medidor-und-0-target-id").blur(function() {
            //Allow only backspace, delete and enter
            var text = this.value;
            var meter = text.substring(text.lastIndexOf("(")+1,text.lastIndexOf(")"));
            var oldLecture = "";
             
            lectures.forEach(function(entry){
               if(entry['meter'] == meter){
                   oldLecture = entry['lecture'];
               }
               $("#edit-field-lectura-anterior-und-0-value").val(oldLecture);
            });
        });
        
        $("#edit-field-lectura-actual-und-0-value").change(function() {
            //Allow only backspace, delete and enter
            var currentLecture = parseInt(this.value);
            var oldLecture = parseInt($("#edit-field-lectura-anterior-und-0-value").val());
            var consumption = currentLecture - oldLecture;
            var limit = parseInt(rates['limite']);
            var baseAmount = parseFloat(rates['montoBase']);
            var extraUnit = parseInt(rates['unidadExtra']);
            var extraAmount = parseFloat(rates['montoExtra']);
            var amount = 0;
            
            if (consumption <= limit){
            	amount =  baseAmount;
            }else {
            	amount = baseAmount + (consumption-limit)/extraUnit*extraAmount;
            }
            
            $("#edit-field-monto-und-0-value").val(amount);
            
        });
        
        $("#pagarLecturas").click(function() {
        	$("#mando").val("pagarLecturas");
            
        });
        $("#filtrar").click(function() {
        	$("#mando").val("filtrar");
            
        });
        
        
    });
       
})(jQuery);



